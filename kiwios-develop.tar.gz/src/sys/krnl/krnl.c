#include <sys/krnl.h>
#include <vga.h>

console_t console = { 0 };
