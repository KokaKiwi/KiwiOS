#ifndef WORDSIZE_H_
#define WORDSIZE_H_

#define __WORDSIZE 32

#endif
