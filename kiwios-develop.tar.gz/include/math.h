#ifndef MATH_H_
#define MATH_H_

double pow(double, double);

#endif